package opserver;
public class UpdatedPrice extends Product
{
    public UpdatedPrice(int price, Subject s) 
    {
     super(price,s);
        
    }
    @Override
    public void updatePrice() 
    {
    }
    
}
