package timerapp;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.Timer;
public class firstWindow extends JPanel
{
   private JButton btn1,btn2,btn3;  
   private ButtonGroup bgroup = new ButtonGroup();
   private JTextField tField1,tfield2;
   private Timer timer,timer1;
   private JLabel label;
   private int k,c;
   private JComboBox speed;
   private JScrollPane p1;
             
    public firstWindow() throws ParseException 
    { 
        setPreferredSize(new Dimension(500,300));
        btn1 = new JButton("Start");
        btn2 = new JButton("Stop"); 
       // Osluskivac o1 = new Osluskivac();
        add(btn1);
       // btn1.addActionListener(o1);
        add(btn2);  
        //btn2.addActionListener(o1);
        btn3 = new JButton("Choose Color");
        add(btn3);
        //btn3.addActionListener(o1);
        
        JRadioButton radioBtn1 = new JRadioButton();
        radioBtn1.setText("on time:");
                                   
        JRadioButton radioBtn2 = new JRadioButton();
        radioBtn2.setText("countdown");
         
        bgroup.add(radioBtn1);
        bgroup.add(radioBtn2);
        
        add(radioBtn1);
        add(radioBtn2);
        
        /*tField1 = new JTextField();
        tField1.setColumns(8);*/
          
        
       
       /* timer1 = new Timer(1000,new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                System.out.println(c);
                c--;
                timer1.start();
            }
            
        });*/
         add(tField1);
        
       SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
       JFormattedTextField tfield2 = new JFormattedTextField(timeFormat);
       tfield2.setColumns(8);
       tfield2.setValue(0);
        btn1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

                if(radioBtn1.isSelected())
                {
                    System.out.println("countdown");
                    timer = new Timer(100, new ActionListener()
                    {
                        @Override
                        public void actionPerformed(ActionEvent e)
                        {
                            System.out.println(k);
                            k++;
                            timer.start();
                        }
                    });
          timer.start();
                }
            }        
          if(radioBtn2.isSelected())
          {
          System.out.println("CountUp");
          timer = new Timer(1000, new ActionListener()
          {
            @Override
            public void actionPerformed(ActionEvent e)
            {
              System.out.println(k);
              k++;
              timer.start();
            }
          });
          timer.start();
        }
        });

      
        
      /* timer = new Timer(1000,new ActionListener()
       {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(k);
                k++;
                timer.start();
            }
           
       });*/
       add(tfield2);
 
       String[] strings = { " 1 ", " 2 ", " 3 ", " 4 ", " 5 " };
       speed = new JComboBox(strings);
       add(speed);
       
        
                
     
        
    }    
}
       //p1.setViewportView(speed);
      /* tfield2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
               JOptionPane.showInputDialog(e);
            }            
        });*/
      
       
                                                            
   /*  private class Osluskivac implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
             if((e.getSource())== btn1)
             {
                 timer.setRepeats(false);
                 timer.start();
                 timer1.start();
             }
             if((e.getSource()) == btn2)
             {
                  timer.stop();
                  timer1.stop();
             }
             if((e.getSource())== btn3)
             {
                JColorChooser jcc = new JColorChooser();
                jcc.removeChooserPanel(jcc.getChooserPanels()[0]);
               
                JDialog dialog = JColorChooser.createDialog(null, "Choose color", true, jcc, new ActionListener() 
                {
                    @Override
                    public void actionPerformed(ActionEvent e) 
                    {
                     
                    }
                }   ,null);
                dialog.setVisible(true);

             }*/
                   
                
    

       /* lButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {               
            }            
        });*/               
        //rButton.addActionListener(o1);
        //lButton.addActionListener(o1);
       /* tField1 = new JTextField();
        String vreme = tField1.getText();
        tField1.setText(vreme);*/
        
       //final DateTimeFormatter timeFormater = DateTimeFormatter.ofPattern("HH:mm:ss");            
       // final LocalDate localDate = LocalDate.parse(vreme);
                                                            
        /*DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getDefault());
        Date date = dateFormat.parse(vreme);
        long seconds = date.getTime() / 1000L;*/ 

